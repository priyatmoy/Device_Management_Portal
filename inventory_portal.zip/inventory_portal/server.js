// var express=require('express');
// var path=require('path');
// var dh=require('./dbaccess/queries');
// //var dh=require('firebase/database');
// var fs = require('fs');
// var bodyParser=require('body-parser');
// var app=express();
// app.use(bodyParser());
// app.use(express.static('public'));

// app.post('/api/loginAPI',function(req,res){
    // dh.getLoginDetails(req,res);
    // });

// app.post('/api/checkAvailabilityAPI',function(req,res){
    // dh.getAvailableDevicesFromDateRange(req,res);
// });


// /*GET API START*/


// /*app.get('/api/allVisibleDeviceAPI',function(req,res){
    // dh.getAllVisibleDevices(req,res);
// });*/

// /*GET API END*/
// app.post('/api/getDeviceDetailsAPI',function(req,res){
    // dh.getDeviceDetails(req,res);
// });

// app.post('/api/checkDevReqAPI',function(req,res){
    // dh.checkBeforeApprove(req,res);
// });
// app.post('/api/completeRequestAdminAPI',function(req,res){
    // dh.completeRequestAdmin(req,res);
// });

// app.post('/api/getAllMappingAdminAPI',function(req,res){
    // dh.getMappingAdmin(req,res);
// });
// app.post('/api/returnUserDeviceAPI',function(req,res){
    // dh.returnDevice(req,res);
// });

// app.post('/api/updateDeviceAPI',function(req,res){
    // dh.updateDeviceAdmin(req,res);
// });

// app.post('/api/reqHistoryAPI',function(req,res){
    // dh.getUserReqHistory(req,res);
// });
// app.post('/api/deviceReqAcceptAPI',function(req,res){
    // dh.acceptMobileRequest(req,res);
// });
// app.post('/api/deviceReqRejectAPI',function(req,res){
    // dh.rejectMobileRequest(req,res);
// });
// app.post('/api/deviceReqAPI',function(req,res){
    // dh.getDeviceRequest(req,res);
// });

// app.post('/api/rejectUserAPI',function(req,res){
    // dh.rejectUserByAdmin(req,res);
// });
// app.post('/api/adminDashMetaAPI',function(req,res){
    // dh.adminDashboardMetaData(req,res);
// });

// app.post('/api/addDeviceRequestAPI',function(req,res){
    // dh.insertDeviceRequest(req,res);
    // });
// app.post('/api/registerAPI',function(req,res){
    // dh.registerUser(req,res);
    // });

// app.post('/api/getAllDevicesAPI',function(req,res){
    // dh.getAllDevicesDetailsAdmin(req,res);
    // });

// app.post('/api/addDeviceAPI',function(req,res){
    // dh.insertDeviceByAdmin(req,res);
    // });

// app.post('/api/changeAccountPasswordAPI',function(req,res){
    // dh.updateAccountPassword(req,res);
    // });
// app.post('/api/acceptUserAdminAPI',function(req,res){
    // dh.acceptUserAdmin(req,res);
    // });

    // app.post('/api/deviceHistoryAPI',function(req,res){
    // dh.getDeviceHistory(req,res);
    // });

    // app.post('/api/getAllUsersAPI',function(req,res){
    // dh.getAllUsers(req,res);
    // });




// //get Static Databse content from tacos.json 
    // app.post('/api/requestTab',function(req,res){
        // dh.getPendingUserDetails(req,res);
    // /*fs.readFile('public/database/requestsDT.json', 'utf8', function (err, data) {
    // if (err) {console.log(err);};
        // res.send(""+data);*/
// });    


   // app.get('/api/mobileRequests',function(req,res){
    // fs.readFile('public/database/requestsDevices.json', 'utf8', function (err, data) {
    // if (err) {console.log(err);};
        // res.send(""+data);
// });    
    // });


// app.get('/admin/*', function (req, res) {
    // //onsole.log("loc:"+ req.originalUrl);
   // // console.log("locAfter:"+ req.originalUrl.replace("/admin", ""));
    // res.redirect('/admin/#' + req.originalUrl.replace("/admin", ""));
    
// });

// app.get('/user/*', function (req, res) {
    // //onsole.log("loc:"+ req.originalUrl);
   // // console.log("locAfter:"+ req.originalUrl.replace("/admin", ""));
    // res.redirect('/user/#' + req.originalUrl.replace("/user", ""));
    
// });

// app.get('*', function (req, res) {
    // res.redirect('/#' + req.originalUrl);
// });



 


// app.listen(2999,function(){
    // console.log('Server is listening on port 2999..');
// });