(function() {
  // Initialize Firebase
    var config = {
    apiKey: "AIzaSyC3-B8PBbkaDXeyp0SjAdTMC8Fi74O_Q_4",
    authDomain: "inventory-c7909.firebaseapp.com",
    databaseURL: "https://inventory-c7909.firebaseio.com",
    projectId: "inventory-c7909",
    storageBucket: "inventory-c7909.appspot.com",
    messagingSenderId: "272240576329"
  };
  if (!firebase.apps.length) {
  firebase.initializeApp(config);
}
 
  angular
 .module('MyApp', ['ngRoute', 'satellizer', 'firebase'])
 .config(function($routeProvider, $locationProvider, $authProvider) {
   $locationProvider.html5Mode(true);
   $routeProvider
   .when('/', {
     templateUrl: 'partials/auth/loginPage.html',
     controller: 'LoginCtrl',
     pageTitle: 'Portal :: Login',
     resolve: {skipIfAuthenticated : skipIfAuthenticated}
   })
  .when('/register', {
     templateUrl: 'partials/auth/signUpPage.html',
     controller: 'SignUpCtrl',
     pageTitle: 'Portal :: Register',
     resolve: {skipIfAuthenticated : skipIfAuthenticated}
   })
    .when('/admin', {
    controller : function(){
      window.location.replace('/admin/');
     }, 
     template : "<div>loading...</div>"
   })
   .when('/user', {
    controller : function(){
     window.location.replace('/user/');
     }, 
     template : "<div>loading...</div>"
   })
   .otherwise({
     pageTitle: '404 - Not Found',
    templateUrl: 'partials/404.html'
   });

function loginRequired($location, $window) {
     if(!$window.localStorage.user) {
       $location.path('/');
     }
   }
    
     function skipIfAuthenticated($location,$window){
          if($window.localStorage.user) {
           // //  $location.path('/dashboard');
              var role=JSON.parse($window.localStorage.user).role;
              console.log("role:"+role);
              if(role=='admin')
                  $location.path('/admin');
              else if(role=='user')
                 $location.path('/user');
          }
     }

 })

 .run(function($rootScope, $window,$auth, $route) {
  
   $rootScope.show_wrapper = true;

   if ($window.localStorage.user) {
     $rootScope.currentUser = JSON.parse($window.localStorage.user);
   }

   $rootScope.$on("$routeChangeSuccess", function(currentRoute, previousRoute){
     $rootScope.title = $route.current.pageTitle;
   });

 })
     .controller('MyCtrl', function($scope, $firebaseObject,$firebaseArray){
	// var ref = firebase.database().ref("user_registration");
    // var list = $firebaseArray(ref);
	// ref.on('value', snap => console.log(snap.val()));

    // list.$loaded().then(function() {
       // $scope.list = [];
       // angular.forEach(list, function(value,key){
          // $scope.list.push({ id: key, data: value});
       // })
	   // console.log($scope.list);
    // });
	//const rootRef = firebase.database().ref().child('object');
         //const ref = rootRef.child('object');
		 //this.object = $firebaseObject(ref);
		//rootRef.on('value', snap => console.log(snap.val()));

    });
	
}());