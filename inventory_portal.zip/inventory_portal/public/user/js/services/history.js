angular.module('MyApp')
  .factory('HistoryService', function($http) {
    return {
       
    
       getUserHistory: function(data) {
        return $http.post('/api/reqHistoryAPI',data);
      },
        returnDeviceACK: function(data) {
        return $http.post('/api/returnUserDeviceAPI',data);
      }
    };
  });