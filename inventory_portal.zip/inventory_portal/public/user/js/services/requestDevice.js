// angular.module('MyApp')
  // .factory('RequestDeviceService', function($http) {
    // return {
       
    
       // checkDeviceAvailablity: function(data) {
        // return $http.post('/api/checkAvailabilityAPI',data);
       // },
        // //insertDeviceRequest:function(data) {
        // //return $http.post('/api/addDeviceRequestAPI',data);
       // //}
    // };
  // });