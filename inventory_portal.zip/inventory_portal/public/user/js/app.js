(function() {
  // Initialize Firebase
    var config = {
    apiKey: "AIzaSyC3-B8PBbkaDXeyp0SjAdTMC8Fi74O_Q_4",
    authDomain: "inventory-c7909.firebaseapp.com",
    databaseURL: "https://inventory-c7909.firebaseio.com",
    projectId: "inventory-c7909",
    storageBucket: "inventory-c7909.appspot.com",
    messagingSenderId: "272240576329"
  };
  if (!firebase.apps.length) {
  firebase.initializeApp(config);
}
angular.module('MyApp', ['ngRoute', 'satellizer','firebase'])
.config(function($routeProvider, $locationProvider, $authProvider) {
  $locationProvider.html5Mode(true);
  $routeProvider
  
  .when('/', {
    templateUrl: 'partials/user/dashboard.html',
    controller: 'UserDashboardCtrl',
    pageTitle: 'User :: Dashboard',
    resolve: {loginRequired: loginRequired}
  })
  .when('/settings', {
    templateUrl: 'partials/user/settings.html',
    controller: 'SettingsCtrl',
    pageTitle: 'User :: Settings',
    resolve: {loginRequired: loginRequired}
  })
  .when('/requestDevice', {
    templateUrl: 'partials/user/userRequestDevice.html',
    controller: 'RequestDeviceCtrl',
    pageTitle: 'User :: Request Device',
    resolve: {loginRequired: loginRequired}
  })
  .when('/history', {
    templateUrl: 'partials/user/history.html',
    controller: 'HistoryCtrl',
    pageTitle: 'User :: Device History',
    resolve: {loginRequired: loginRequired}
  })
  .otherwise({
    pageTitle: '404 - Not Found',
    templateUrl: 'partials/404.html'
  });

function loginRequired($location, $window) {
	//console.log('running..');
    if(!$window.localStorage.user) {
      window.location.replace('/');
    }else{//if role other than user tries to access user dashboard reject
        var userObj=JSON.parse($window.localStorage.user);
      //  console.log(userObj);
        if(userObj.role!='user')
         window.location.replace('/');
    }
  }
    /*
    function skipIfAuthenticated($location,$window){
         if($window.localStorage.user) {
             $location.path('/dashboard');
         }
    }
*/
})



.run(function($rootScope, $window,$auth, $route) {
  
  $rootScope.show_wrapper = true;

  if ($window.localStorage.user) {
    $rootScope.currentUser = JSON.parse($window.localStorage.user);
    // $rootScope.currentUserRole = $rootScope.currentUser.role;
  }
/*
  $rootScope.isAuthenticated = function() {
    return $auth.isAuthenticated();
  };
  $rootScope.isProductManager = function() {
    // alert()
    return $auth.isAuthenticated() && ($rootScope.currentUser.role == 'product_manager');
  };
*/
  $rootScope.$on("$routeChangeSuccess", function(currentRoute, previousRoute){
    $rootScope.title = $route.current.pageTitle;
  });

});

}());