angular.module('MyApp')
  .controller('UserDashboardCtrl', function($scope, $rootScope, $location, $window) {
     $rootScope.view_class = "wrapper";
    $rootScope.body_class = "dashboard-class";
    $rootScope.show_wrapper = false;
    console.log($rootScope.currentUser);
    $scope.count={};
    $scope.count.pur=45;
    $scope.count.pdr=55;
    $scope.count.tad=5;
    $scope.count.td=15;
    
    $scope.userDet=JSON.stringify($rootScope.currentUser);
   /* if($rootScope.role==null)
        $location.path('/');*/
    $scope.logout=function(){
        delete $window.localStorage.user;
       // $location.path('/');
	   $window.location.href = '/';
        
    }
    
});