angular.module('MyApp')
  .controller('RequestDeviceCtrl', function($scope, $rootScope, $location, $window,$firebase) {
     $rootScope.view_class = "wrapper";
    $rootScope.body_class = "cream-background";
    $rootScope.show_wrapper = false;
    
    
  initializeSidebarTopbarScript();
    
    $scope.form2=false;
    $scope.form3=false;
    $scope.deviceArray=[];
    $scope.device={
        empid:"",
        mail_id:"",
        manager_mail_id:"",
        device_id:"",
        imei:"",
        software_version:""
    }
    $scope.saveDates={
        fromDateStamp: "" ,
        toDateStamp: ""
    }

	 $scope.getDate ={
		// fromDate:"",
		// fromTime:"",
		// toDate:"",
		// toTime:""
	 }
	 $scope.fromTime = [
	'12:00am','12:30am','1:00am','1:30am','2:00am','2:30am','3:00am','3:30am','4:00am','4:30am',
	'5:00am','5:30am','6:00am','6:30am','7:00am','7:30am','8:00am','8:30am','9:00am','9:30am',
	'10:00am','10:30am','11:00am','11:30am','12:00pm',
	'12:30pm','1:00pm','1:30pm','2:00pm','2:30pm','3:00pm','3:30pm','4:00pm','4:30pm',
	'5:00pm','5:30pm','6:00pm','6:30pm','7:00pm','7:30pm','8:00pm','8:30pm','9:00pm','9:30pm',
	'10:00pm','10:30pm','11:00pm','11:30pm',
	]

		//$scope.testing=function()
		//{
			//alert ("selected");
		//}
		$scope.checkDeviceAvailabilty=function(getDate,selected){
      console.log(getDate.fromDate);
	  console.log(getDate.fromTime);
	  console.log(selected);
        //moment('20 July, 17 1:00am','D MMM, YY h:ma') ->working
     
        if(getDate==null || getDate.fromDate==null || getDate.toDate==null || getDate.fromTime==null || getDate.toTime==null){
            alert("Please Select All Options!");
            return;
        }
         if(getDate.fromDate.trim=="" || getDate.toDate.trim=="" || getDate.fromTime.trim=="" || getDate.toTime.trim==""){
            alert("Please Select All Options!");
            return;
        }

        getDate.fromTimeStamp=getDate.fromDate+" "+getDate.fromTime;
        getDate.toTimeStamp=getDate.toDate+" "+getDate.toTime;
         console.log(" getDate:"+JSON.stringify(getDate));
        var fromDateStamp=moment(getDate.fromTimeStamp,'D MM, YYYY h:ma');
        var toDateStamp=moment(getDate.toTimeStamp,'D MM, YYyY h:ma');
        
       /* console.log("From :"+fromDateStamp);
        console.log("To   : "+toDateStamp);*/
       // console.log("dateDiff:"+moment().diff(fromDateStamp));
        if(moment().diff(fromDateStamp)>=0){
            alert("Select Correct Date!");
            return;
        }else if(fromDateStamp.diff(toDateStamp) >= 0){
            alert(moment(toDateStamp).format('DD-MM-YYYY hh:mm a')+" is(to) before");
            return;
        }
         
        if($scope.form3==true){
            $scope.form3=false;
        }
		  // "select device_id,imei_number,device_password,device_model,software_version,
		  //(select emp_username from user_registration where emp_no=$3 AND status='accept'),
		 // (select emp_manager from user_registration where emp_no=$3 AND status='accept'),
		  //(select emp_project from user_registration where emp_no=$3 AND status='accept')
		  //from devices where device_id NOT IN( select distinct device_id from mapping where 
		  //(status='accept') AND (( from_date >=to_timestamp($1, 'dd-mm-yyyy hh24:mi') AND from_date <=to_timestamp($2, 'dd-mm-yyyy hh24:mi')) OR (to_date >=to_timestamp($1, 'dd-mm-yyyy hh24:mi') AND to_date <=to_timestamp($2, 'dd-mm-yyyy hh24:mi')) OR (from_date <= to_timestamp($1, 'dd-mm-yyyy hh24:mi') AND to_date>=to_timestamp($2, 'dd-mm-yyyy hh24:mi') )) ) AND devices.visibility='Visible';",[fromDate,toDate,empno])

		  //const rootRef = new Firebase("https://inventory-c7909.firebaseio.com");
		   const rootRef = firebase.database().ref();

			rootRef.child('user_registration').once('value', function(userSnap) {
				rootRef.child('devices').once('value', function(deviceSnap) {
					rootRef.child('mapping').once('value', function(mapSnap){
							console.log( userSnap.val() );
							console.log( deviceSnap.val() );
							console.log( mapSnap.val() );
					});
			});
		});
        // RequestDeviceService.checkDeviceAvailablity({
            // fromDate:""+moment(fromDateStamp).format('DD-MM-YYYY kk:mm'),
            // toDate:""+moment(toDateStamp).format('DD-MM-YYYY kk:mm'),
            // empno: ""+$rootScope.currentUser.username
        // }).then(function(data){
              // console.log("success:"+JSON.stringify(data));
                // if(data.status==200){
                 // $scope.deviceArray=data.data.data;
                    // if($scope.deviceArray.length==0){
                        // alert("No Devices Are Available for selected Dates!");
                        // $scope.form2=false;
                        // return;
                    // }
                    // $scope.form2=true;
                 // $scope.saveDates.fromDateStamp=""+getDate.fromTimeStamp;
                 // $scope.saveDates.toDateStamp=""+getDate.toTimeStamp;
                    
                // }else{
                    // alert("Error.. Devices not Fetched!!");
                // }            
            // }),function(data){
                // console.log("Error:"+JSON.stringify(data));
            // }
        $scope.deviceSelectedId="-Select-";
        
        //$scope.form3=false;
       // $('#checkButton').prop('disabled',true);
                
    }
    function getdeviceDetailsFromIMEI(imei){
        for(var i=0;i<$scope.deviceArray.length;i++)
            if($scope.deviceArray[i].imei_number==imei)
                return i;
        return -1;
    }
    $scope.selectedChange=function(deviceId){
        console.log("Selcted DeviceId:"+deviceId);
        var idx=getdeviceDetailsFromIMEI(deviceId);
        if(deviceId=='-Select-' || idx==-1){
            $scope.form3=false;
            alert("Select Correct Device!");
            return;
        }
        console.log("idex:"+idx);
        $scope.form3=true;
        
        $scope.device.empid=$rootScope.currentUser.username;
        $scope.device.mail_id=$scope.deviceArray[idx].emp_username;
        $scope.device.manager_mail_id=$scope.deviceArray[idx].emp_manager;
        $scope.device.device_id=$scope.deviceArray[idx].device_id;
        $scope.device.imei=$scope.deviceArray[idx].emp_project;
        $scope.device.device_password=$scope.deviceArray[idx].device_password;
        $scope.device.device_model=$scope.deviceArray[idx].device_model;
        $scope.device.software_version=$scope.deviceArray[idx].software_version;
       // $scope.device.software_version="From:"+$scope.saveDates.fromDateStamp+" To:"+$scope.saveDates.toDateStamp;
    }
    
    $scope.cancelBtn=function(){
        $location.path("/");
    }
    
    $scope.requestDevice=function(deviceData){
        console.log(deviceData);
        console.log($scope.saveDates);
        
        var frommillis=moment($scope.saveDates.fromDateStamp,'D MMM, YY h:ma');
        var tomillis=moment($scope.saveDates.toDateStamp,'D MMM, YY h:ma');
        
        // RequestDeviceService.insertDeviceRequest({
            // from_date:""+moment(frommillis).format('DD-MM-YYYY kk:mm'),
            // to_date:""+moment(tomillis).format('DD-MM-YYYY kk:mm'),
            // empno: ""+$rootScope.currentUser.username,
            // device_id:deviceData.device_id,
            // emp_username:deviceData.mail_id,
            // comment: deviceData.comments
            
        // }).then(function(data){
              // console.log("success:"+JSON.stringify(data));
                // if(data.status==200){
                    // alert('Request Successfully Submitted!');
                // $location.path('/');
                // }
                    
            // }),function(data){
                // console.log("Error:"+JSON.stringify(data));
            // }
        
        
       }
        
        

    
});