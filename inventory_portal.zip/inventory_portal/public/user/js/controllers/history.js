angular.module('MyApp')
  .controller('HistoryCtrl', function($scope, $rootScope, $location, $window, HistoryService) {
     $rootScope.view_class = "wrapper";
    $rootScope.body_class = "body-class";
    $rootScope.show_wrapper = false;
    $rootScope.containerId="wrapper";
      $scope.initialize=function(){
        $('#dataTable-container').hide();
         $('.loader').show();
       HistoryService.getUserHistory({
           empno:""+$rootScope.currentUser.username
       }).then(function(data){
             
                if(data.status==200){
                   console.log("data is:"+JSON.stringify(data.data.data));  
                    //$scope.dataTable=[];
                    $scope.dataTable=data.data.data; 
                    
                    console.log($scope.dataTable);
                     $('#dataTable-container').show();
                    $('.loader').hide();
                }            
            }),function(data){
                console.log("Error:"+data);
            }
       
        /*$('#dataTable-container').show();
                    $('.loader').hide();*/
    
    }
      
      
      $scope.returnBtn=function(obj){
          console.log("Return Value:"+JSON.stringify(obj));
          HistoryService.returnDeviceACK({
           request_id:""+obj.request_id
       }).then(function(data){
             
                if(data.status==200){
                   console.log("data is:"+JSON.stringify(data.data.statusOk));  
                    if(data.data.statusOk==true){
                        alert('Device Successfully Returned from User Side! ');
                        $location.path('/');
                    }                }            
            }),function(data){
                console.log("Error:"+data);
            }
          
          
          
      }
      
    
});