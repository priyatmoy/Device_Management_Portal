
function initializeSidebarTopbarScript(){
    console.log("Scripts initialized..");
 
   /* $( function() {*/
    $( "#datePickerFrom" ).datepicker({
         showButtonPanel: true,
      changeMonth: true,
      changeYear: true
    });    
     $( "#datePickerTo" ).datepicker({
         showButtonPanel: true,
      changeMonth: true,
      changeYear: true
    });
    
     $( "#datePickerFrom" ).datepicker( "option", "dateFormat", "d MM, y" );
     $( "#datePickerTo" ).datepicker( "option", "dateFormat", "d MM, y" );
    
    $('#fromTime').timepicker({
       useSelect: false,
        disableTextInput: true,
        //disableTimeRanges: [['12:00am', '9:00am'],['5:00pm','11:45pm']]
    });
    $('#toTime').timepicker({
        useSelect: false,
        disableTextInput: true,
        //disableTimeRanges: [['12:00am', '9:00am'],['5:00pm','11:45pm']]
    });
 /* } );*/
    
    
}
