
function initializeSidebarTopbarScript(){
    console.log("Scripts initialized..");
   $("#wrapper").addClass("toggled");
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
         console.log("..");
        if($('#wrapper').hasClass('toggled'))
            $('#wrapper').removeClass('toggled');
        else
         $("#wrapper").addClass("toggled");
        //$("#wrapper").toggleClass("toggled");
    });
}
