// angular.module('MyApp')
  // .factory('deviceHistory', function($http) {
    // return {
       
    
       // getDeviceHistory: function(data) {
        // return $http.post('/api/deviceHistoryAPI',data);
      // }
         
    // };
  // });