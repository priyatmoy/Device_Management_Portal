// angular.module('MyApp')
  // .factory('RequestUserService', function($http) {
    // return {
       
    
       // getPendingUserDetails: function() {
        // return $http.post('/api/requestTab');
      // },
       // acceptUserAdmin: function(data) {
        // return $http.post('/api/acceptUserAdminAPI',data);
      // },
        // rejectUserAdmin: function(data){
        // return $http.post('/api/rejectUserAPI',data);
        // }
    // };
  // });