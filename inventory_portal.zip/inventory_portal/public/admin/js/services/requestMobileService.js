angular.module('MyApp')
  .factory('RequestMobile', function($http) {
    return {
       
    
       getMappingData: function() {
        return $http.post('/api/deviceReqAPI');
      },
        acceptDevice: function(data) {
        return $http.post('/api/deviceReqAcceptAPI',data);
      },
        rejectDevice: function(data) {
        return $http.post('/api/deviceReqRejectAPI',data);
      },
         checkRequestDevice: function(data) {
        return $http.post('/api/checkDevReqAPI',data);
      }
    };
  });