// angular.module('MyApp')
  // .factory('AddUserService', function($http) {
    // return {
       
    
       // addUserAccout: function(data) {
        // return $http.post('/api/registerAPI',data);
      // }
    // };
  // });