angular.module('MyApp')
  .factory('SettingsService', function($http) {
    return {
       
    
       changeAccountPassword: function(data) {
        return $http.post('/api/changeAccountPasswordAPI',data);
      }
    };
  });