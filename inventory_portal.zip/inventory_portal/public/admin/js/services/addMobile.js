// angular.module('MyApp')
  // .factory('AddMobileService', function($http) {
    // return {
       
    
       // addMobileDeviceAdmin: function(data) {
        // return $http.post('/api/addDeviceAPI',data);
      // }
    // };
  // });