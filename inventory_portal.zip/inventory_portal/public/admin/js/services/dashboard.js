// angular.module('MyApp')
  // .factory('DashboardService', function($http) {
    // return {
       
    
       // getMetaData: function() {
        // return $http.post('/api/adminDashMetaAPI');
      // }
    // };
  // });