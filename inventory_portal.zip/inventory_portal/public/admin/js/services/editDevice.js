// angular.module('MyApp')
  // .factory('EditDeviceService', function($http) {
    // return {
       
    
       // getAllDeviceDetails: function() {
        // return $http.post('/api/getAllDevicesAPI');
      // },
      // updateDevice: function(data){
          // return $http.post('/api/updateDeviceAPI',data);
      // }
    // };
  // });