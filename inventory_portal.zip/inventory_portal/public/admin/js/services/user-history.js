// angular.module('MyApp')
  // .factory('userHistory', function($http) {
    // return {
       
    
       // getUserInfo: function(data) {
        // return $http.post('/api/getAllUsersAPI');
      // },

      // getUserHistory: function(data) {
        // return $http.post('/api/reqHistoryAPI',data);
      // },
         
    // };
  // });