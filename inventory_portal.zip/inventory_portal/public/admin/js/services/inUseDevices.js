angular.module('MyApp')
  .factory('InUseDeviceService', function($http) {
    return {
       
    
       getInUseDevices: function() {
        return $http.post('/api/getAllMappingAdminAPI');
      },
         completeDevice: function(data) {
        return $http.post('/api/completeRequestAdminAPI',data);
      }
    };
  });