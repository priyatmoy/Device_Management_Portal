(function() {
  // Initialize Firebase
    var config = {
    apiKey: "AIzaSyC3-B8PBbkaDXeyp0SjAdTMC8Fi74O_Q_4",
    authDomain: "inventory-c7909.firebaseapp.com",
    databaseURL: "https://inventory-c7909.firebaseio.com",
    projectId: "inventory-c7909",
    storageBucket: "inventory-c7909.appspot.com",
    messagingSenderId: "272240576329"
  };
  if (!firebase.apps.length) {
  firebase.initializeApp(config);
}
var deviceArr=[];
angular.module('MyApp', ['ngRoute', 'satellizer','ui.bootstrap','datatables','ngDialog','firebase'])
.config(function($routeProvider, $locationProvider, $authProvider) {
  $locationProvider.html5Mode(true);
  $routeProvider
  
  .when('/', {
    templateUrl: 'partials/admin/dashboard.html',
    controller: 'DashboardCtrl',
    pageTitle: 'Admin :: Dashboard',
    resolve: {loginRequired: loginRequired}
  })
  /*.when('/dashboard', {
    templateUrl: 'partials/admin/dashboard.html',
    controller: 'DashboardCtrl',
    pageTitle: 'Admin :: Dashboard',
    resolve: {loginRequired: loginRequired}
  })*/
  .when('/requests', {
    templateUrl: 'partials/admin/requests-page.html',
    controller: 'RequestsPageCtrl',
    pageTitle: 'Admin :: Requests',
    resolve: {loginRequired: loginRequired}
  })
   .when('/mobrequests', {
    templateUrl: 'partials/admin/requests-mobile.html',
    controller: 'RequestsMobilePageCtrl',
    pageTitle: 'Admin :: Mob Requests',
    resolve: {loginRequired: loginRequired}
  })
   .when('/editViewDevice', {
    templateUrl: 'partials/admin/edit-device.html',
    controller: 'editDeviceCtrl',
    pageTitle: 'Admin :: Edit/View Device',
    resolve: {loginRequired: loginRequired}
  })
  
   .when('/addDevice', {
    templateUrl: 'partials/admin/add-device.html',
    controller: 'addDeviceCtrl',
    pageTitle: 'Admin :: Add Device',
    resolve: {loginRequired: loginRequired}
  })
   .when('/addUser', {
    templateUrl: 'partials/admin/add-user.html',
    controller: 'addUserCtrl',
    pageTitle: 'Admin :: Add User',
    resolve: {loginRequired: loginRequired}
  })
   .when('/settings', {
    templateUrl: 'partials/admin/settings.html',
    controller: 'SettingsCtrl',
    pageTitle: 'Admin :: Settings',
    resolve: {loginRequired: loginRequired}
  })
   .when('/inuseDevice', {
    templateUrl: 'partials/admin/inuse-device.html',
    controller: 'InUserDeviceCtrl',
    pageTitle: 'Admin :: In Use Device',
    resolve: {loginRequired: loginRequired}
  })
  .when('/deviceHistory', {
    templateUrl: 'partials/admin/device-history.html',
    controller: 'DeviceHistoryCtrl',
    pageTitle: 'Admin :: Device History',
    resolve: {loginRequired: loginRequired}
  })
.when('/userHistory', {
    templateUrl: 'partials/admin/user-history.html',
    controller: 'UserHistoryCtrl',
    pageTitle: 'Admin :: User History',
    resolve: {loginRequired: loginRequired}
  })

  .otherwise({
    pageTitle: '404 - Not Found',
    templateUrl: 'partials/404.html'
  });

function loginRequired($location, $window) {
	//console.log('running..');
    if(!$window.localStorage.user) {
      window.location.replace('/');
    }else{//if role other than admin tries to access user dashboard reject
        var userObj=JSON.parse($window.localStorage.user);
       // console.log(userObj);
        if(userObj.role!='admin')
         window.location.replace('/');
    }
    
    
  }
    /*
    function skipIfAuthenticated($location,$window){
         if($window.localStorage.user) {
             $location.path('/dashboard');
         }
    }
*/
})

.run(function($rootScope, $window,$auth, $route) {
  
  $rootScope.show_wrapper = true;

  if ($window.localStorage.user) {
    $rootScope.currentUser = JSON.parse($window.localStorage.user);
    // $rootScope.currentUserRole = $rootScope.currentUser.role;
  }
/*
  $rootScope.isAuthenticated = function() {
    return $auth.isAuthenticated();
  };
  $rootScope.isProductManager = function() {
    // alert()
    return $auth.isAuthenticated() && ($rootScope.currentUser.role == 'product_manager');
  };
*/
  $rootScope.$on("$routeChangeSuccess", function(currentRoute, previousRoute){
    $rootScope.title = $route.current.pageTitle;
  });

});
}());