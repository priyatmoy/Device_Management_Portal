angular.module('MyApp')
  .controller('InUserDeviceCtrl', function($scope, $rootScope, $location, $window,$http,ngDialog,InUseDeviceService) {
     $rootScope.view_class = "wrapper";
    $rootScope.body_class = "cream-background";
    $rootScope.show_wrapper = false;
    $rootScope.containerId="wrapper";
   initializeSidebarTopbarScript();

    
    
    console.log($rootScope.currentUser);
    $scope.userDet=JSON.stringify($rootScope.currentUser);
    
    /*Initialize Function*/
    $scope.initialize=function(){
       // alert("initialized");
        $('#dataTable-container').hide();
         $('.loader').show();
       InUseDeviceService.getInUseDevices().then(function(data){
             
                if(data.status==200){
                   console.log("data is:"+JSON.stringify(data));  
                    $scope.dataTab=data.data.data; 
                     $('#dataTable-container').show();
                    $('.loader').hide();
                }            
            }),function(data){
                console.log("Error:"+data);
            }
    
    }
    
    
    $scope.completeReqBtn=function(obj){
        console.log("req complete:"+JSON.stringify(obj));
        
        InUseDeviceService.completeDevice({
            request_id: ""+obj.mapping_id
        }).then(function(data){
             
                if(data.status==200){
                   if(data.data.statusOk){
                       alert("Request Completed!");
                       $location.path("/");
                   }
                   
                }            
            }),function(data){
                console.log("Error:"+data);
            }
    }
    
    
    
    
    
    
    
    
    
    
});

