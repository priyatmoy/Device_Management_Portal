angular.module('MyApp')
  .controller('DashboardCtrl', function($scope, $rootScope, $location, $window,firebase, $firebaseArray) {
     $rootScope.view_class = "wrapper";
    $rootScope.body_class = "dashboard-class";
    $rootScope.show_wrapper = false;
    $rootScope.containerId="wrapper";
   initializeSidebarTopbarScript();
    $scope.count={};
    $scope.count.pur=0;
    $scope.count.pdr=0;
    $scope.count.tad=0;
    $scope.count.td=0;
    
    
    
        //getMetaData().then(function(data){
           //console.log(JSON.stringify(data.data.data));
            // if(data.status==200 && data.data.statusOk==true){
               // $scope.count.pur=data.data.data[0].pending_user;
                // $scope.count.pdr=data.data.data[1].pending_dev_req;
                // $scope.count.tad=data.data.data[3].avail_dev;
                // $scope.count.td=data.data.data[2].tot_dev;
            // }
        // }),function(data){
                // console.log("Error:"+JSON.stringify(data));
            // }
    
    
    
    console.log($rootScope.currentUser);
    $scope.userDet=JSON.stringify($rootScope.currentUser);
   /* if($rootScope.role==null)
        $location.path('/');*/
    $scope.logout=function(){
        delete $window.localStorage.user;
       // $location.path('/');
	   $window.location.href = '/';
        
    }
    
    $scope.userRequestsClick=function(){
        window.location.href="/admin/requests";
    }
    
});