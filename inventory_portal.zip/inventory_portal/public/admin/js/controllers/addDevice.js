angular.module('MyApp')
  .controller('addDeviceCtrl', function($scope, $rootScope, $location, $window, firebase, $firebaseArray) {
     $rootScope.view_class = "wrapper";
    $rootScope.body_class = "cream-background";
    $rootScope.show_wrapper = false;
    $rootScope.containerId="wrapper";
    
    alert("hi");
    $scope.cancelBtn=function(){
         $location.path('/');
    }

    $scope.register_device=function(device){
       
        /*console.log(JSON.stringify(device));*/
        
        if(device.sim)
            console.log("True");
        else{
            console.log("False");
            device.phone='NA';
        }
        //angular.copy({},device);
        if(device.sim==false){
            device.phone='NA';
        }
         console.log(JSON.stringify(device));
		 const ref = firebase.database().ref().child('devices');
		$scope.registerDevice = $firebaseArray(ref);
		
        $scope.registerDevice.$add({
			deviceModel: device.deviceModel,
			devicePassword:device.password,
			devideId: device.id,
			imeiNumber: device.imei,
			simCard: device.sim,
			PhoneNumber:device.phone,
			softwareVersion:device.softVersion,
			staus: device.deviceStatus,
			visibility:device.visibility
		}).then(function(data){
			alert("device registered with imea number:" + device.imei);
			$location.path('/');
		}),function(data){
                alert("Error Adding Device... please check IMEA number or connection...");
                 console.log("Error:"+data);
             }
           // AddMobileService.addMobileDeviceAdmin(device).then(function(data){
             
                // if(data.status==200){
                   // console.log("data Returned is:"+JSON.stringify(data.data));  
                    // //$scope.dataTable=[];
                     // alert("device registered with imea number:"+data.data.data.imei_number);
                    
                // }            
            // }),function(data){
               // alert("Error Adding Device... please check IMEA number or connection...");
                // console.log("Error:"+data);
            // }
        
        

    }
    
});