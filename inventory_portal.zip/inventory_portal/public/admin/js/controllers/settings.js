angular.module('MyApp')
  .controller('SettingsCtrl', function($scope, $rootScope, $location, $window,SettingsService) {
     $rootScope.view_class = "wrapper";
    $rootScope.body_class = "body-class";
    $rootScope.show_wrapper = false;
    $rootScope.containerId="wrapper";

    $scope.changePassword=function(pass){
        
         if(pass==null || pass.newPass==null || pass.confirmPass==null || pass.confirmPass.trim=="" || pass.newPass.trim==""){
            alert("Fields cannot be kept empty!");
            return;
        }
        var regEx=/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]{8,12}/;  
        if(!regEx.test(""+pass.newPass)){
            alert("Password Should be of Minimum 8 and maximum 12 characters, at least one uppercase letter, one lowercase letter, one number and one special character.");
            return;
        }
        
        if(pass.newPass==pass.confirmPass){
            //change password
            
            
            
            SettingsService.changeAccountPassword({
                newPassword: ""+pass.newPass,
                empno: ""+$rootScope.currentUser.username
            }).then(function(data){
             
                if(data.status==200){
                 // console.log("Error:"+data);
                    alert("Password Changed Successfully!!");
                    $location.path('/');
                }else{
                    alert("Error.. Password not changed!!");
                }            
            }),function(data){
                console.log("Error:"+JSON.stringify(data));
            }
            
            
        }   else{
            alert("Passwords donot Match!!");
        }     
       //console.log("details are:"+JSON.stringify($rootScope.currentUser));
    }
 $scope.cancelBtnClick=function(){
        $location.path('/');
    }

});