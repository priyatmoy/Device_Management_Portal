angular.module('MyApp')
  .controller('editDeviceCtrl', function($scope, $rootScope, $location, $window,firebase, $firebaseObject) {
     $rootScope.view_class = "wrapper";
    $rootScope.body_class = "cream-background";
    $rootScope.show_wrapper = false;
    $rootScope.containerId="wrapper";
   initializeSidebarTopbarScript();
   
    $scope.devicesArray=[];
	
	const rootRef = firebase.database().ref().child('devices');
	$scope.deviceData = $firebaseObject(rootRef);
	
	$scope.deviceData.$loaded()
		.then(function(data) {
			console.log(data === $scope.deviceData); // true
			//$scope.devicesArray= data;
			 angular.forEach(data, function(value, key) {

		  var exists = false;
		angular.forEach($scope.devicesArray, function(val2, key) {
			if(angular.equals(value.imeiNumber, val2.imeiNumber)){ exists = true }; 
		});
		if(exists == false && value.imeiNumber != "") { $scope.devicesArray.push(value); }
	
       });
	   
			if($scope.devicesArray.length>0)
            $scope.deviceSelectedId="-Select-";//+data.data.data[0].imei_number;
                   
		})
		.catch(function(error) {
           console.error("Error:", error);
		});
	
    
       // EditDeviceService.getAllDeviceDetails().then(function(data){
             
                // if(data.status==200){
                   // console.log("data is:"+JSON.stringify(data.data)); 
                    // $scope.devicesArray=data.data.data;
                    // if($scope.devicesArray.length>0)
                        // $scope.deviceSelectedId="-Select-";//+data.data.data[0].imei_number;
                   
                    // //$scope.dataTable=[];
                // }            
            // }),function(data){
                // console.log("Error:"+data);
            // }
    
    /*$scope.devicesArray=[
        {
            "name": "Android mob1",
            "id":"ANDRO234T"
        },
        {
            "name": "Android mob1",
            "id":"IPHONO233T"
        },
        {
            "name": "Android mob1",
            "id":"WINDO334T"
        },
        {
            "name": "Android mob1",
            "id":"SYMBI304T"
        },
        {
            "name": "Android mob1",
            "id":"ANDRO004T"
        }
    ];
    $scope.deviceSelectedId="SYMBI304T";*/
    
     function getdeviceDetailsFromIMEI(imei){
         for(var i=0;i< $scope.devicesArray.length;i++)
             if($scope.devicesArray[i].imeiNumber==imei)
                 return i;
         return -1;
     }
     $scope.selectedChange=function(deviceId){
       
        $scope.device =$scope.devicesArray[getdeviceDetailsFromIMEI(deviceId)];
        //console.log(JSON.stringify($scope.deviceInfo));;
     }
     $scope.cancelBtn=function(){
         $location.path('/');
     }
    
     $scope.updateDeviceProfile=function(device){
         if(device.simCard==false)
             device.phone_number='NA';
         if($scope.deviceSelectedId=='-Select-'){
             alert('Please select a valid Device!');
            return;
         }
            
        console.log("updated DeviceProfile:"+JSON.stringify(device));

		//vay key  = $scope.device.imeiNumber;
		//var query = rootRef.push().key;
		//$scope.deviceData.$bindTo($scope, "device").then(function() {
		//	console.log($scope.device); // { foo: "bar" }
			//$scope.device.simCard = "baz";  // will be saved to the database
			//$scope.device.PhoneNumber = "baz";
			//rootRef.set({ device });  // this would update the database and $scope.data
						 // angular.forEach($scope.devicesArray, function(value, key) {

		  // var exists = false;
		// angular.forEach(rootRef, function(val2, key) {
			// if(angular.equals(value.imeiNumber, val2.imeiNumber)){ exists = true }; 
		// });
		// if(exists == false && value.imeiNumber != "") { 
				// rootRef.update({
				 // PhoneNumber : device.PhoneNumber,
				 // simCard: device.simCard,
				 // visibility: device.visibility
			 // }) }
	
       // });
	   // query.on('value', function(snap) {
		   //Running code
			// var rootRef = firebase.database().ref().child('devices');//'user-posts/' + myUserId
			// var key = rootRef.push().key;
			// var update = {};
			// update[key] = {
				// PhoneNumber : device.PhoneNumber,
				// simCard: device.simCard,
				// visibility: device.visibility,
			    // deviceModel: device.deviceModel,
				// devicePassword:device.devicePassword,
				// devideId: device.devideId,
				// imeiNumber: device.imeiNumber,
				// softwareVersion:device.softwareVersion,
			// }
			  // rootRef.update(update);
		// }
	const rootRef = firebase.database().ref().child('devices');
	$scope.deviceData = $firebaseObject(rootRef);
	
	$scope.deviceData.$loaded()
		.then(function(data) {
			console.log(data === $scope.deviceData); // true
			//$scope.devicesArray= data;
			 angular.forEach(data, function(value, key) {
				console.log(value);
				console.log(key);
			if($scope.device.imeiNumber == value.imeiNumber){
				//var key = rootRef.push().key;
			 var update = {};
			 update[key] = {
				 PhoneNumber : device.PhoneNumber,
				 simCard: device.simCard,
				 visibility: device.visibility,
			     deviceModel: device.deviceModel,
				 devicePassword:device.devicePassword,
				 devideId: device.devideId,
				 imeiNumber: device.imeiNumber,
				 softwareVersion:device.softwareVersion,
			 }
			   rootRef.update(update);
			}
			alert("Device Successfully Updated!!");
            $location.path('/');
		  // var exists = false;
		// angular.forEach($scope.device, function(val2, key) {
			// if(angular.equals(value.imeiNumber, val2.imeiNumber)){ exists = true }; 
		// });
		// if(exists == false && value.imeiNumber != "") { 
		
		// }
	
       });
		});
		}
	   

			 console.log(rootRef);
// });
        // EditDeviceService.updateDevice(device).then(function(data){
             
                // if(data.status==200){
                   // console.log("data is:"+JSON.stringify(data)); 
                    // if(data.data.statusOk){
                    // alert("Device Successfully Updated!!");
                    // $location.path('/');
                    // }
                // }            
            // }),function(data){
                // console.log("Error:"+data);
            // }
        
        
     //}
});