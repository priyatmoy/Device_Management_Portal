
angular.module('MyApp')
  .controller('RequestsMobilePageCtrl', function($scope, $rootScope, $location, $window,$http,ngDialog,RequestMobile) {
     $rootScope.view_class = "wrapper";
    $rootScope.body_class = "cream-background";
    $rootScope.show_wrapper = false;
    $rootScope.containerId="wrapper";
   initializeSidebarTopbarScript();

    
    
    console.log($rootScope.currentUser);
    $scope.userDet=JSON.stringify($rootScope.currentUser);
    
    /*Initialize Function*/
    $scope.initialize=function(){
        
        $('#dataTable-container').hide();
         $('.loader').show();
		 //select m.mapping_id,m.comment,m.device_id,m.emp_no,u.emp_username,to_char(m.from_date, 
		 //'DD Mon,YY HH:miam') as from_date,to_char(m.to_date, 'DD Mon,YY HH:miam') 
		 //as to_date from mapping m inner join user_registration u on m.emp_no=u.emp_no where m.status='pending' order by m.mapping_id desc;
       // RequestMobile.getMappingData().then(function(data){
             
                // if(data.status==200){
                   // console.log("data is:"+JSON.stringify(data.data.data));  
                    // $scope.dataTab=data.data.data; 
                     // $('#dataTable-container').show();
                    // $('.loader').hide();
                // }            
            // }),function(data){
                // console.log("Error:"+data);
            // }
    
    }
    
    
    
    $scope.fetchDeviceDetails=function(deviceId){
       //alert("device id: "+deviceId); 
          $scope.selectedDeviceid=deviceId;   
        /*ngDialog.open({ template: 'mobileDetailsTemplate' });*/
        ngDialog.open({
        template: 'mobileDetailsTemplate.html',
            showClose: false,
            className: 'ngdialog ngdialog-theme-default',
            scope : $scope // This line did the trick
        });
        
       /* ngDialog.open({
            template: '<p>Devide id is '+$scope.selectedDeviceid+'</p>',
            controller: function($scope) {
        // controller logic
        }
        });*/
        
    }
    
    $scope.acceptMobReq=function(obj){
        
        
        console.log(obj);
        var checkObjHoder={};
        //09 Aug,17 01:30am
        var fromDate_mills=moment(obj.from_date,'DD MMM,YY hh:mma');
        var toDate_mills=moment(obj.to_date,'DD MMM,YY hh:mma');
        
       /* console.log("fromDatein24hr:"+moment(fromDate_mills).format('DD-MM-YYYY kk:mm'));
        console.log("toDatein24hr:"+moment(toDate_mills).format('DD-MM-YYYY kk:mm'));*/
        checkObjHoder.device_id=obj.device_id;
        checkObjHoder.from_date=""+moment(fromDate_mills).format('DD-MM-YYYY kk:mm');
        checkObjHoder.to_date=""+moment(toDate_mills).format('DD-MM-YYYY kk:mm');    
        console.log(JSON.stringify(checkObjHoder));
        
        RequestMobile.checkRequestDevice(checkObjHoder).then(function(data){
             
                if(data.status==200 && data.data.statusOk==true){
                if(data.data.canApprove==false){//if duplicate exists
                    alert("Device Already in use.. Cannot Accept!");
                    return;
                }else{
                    
                    
                     RequestMobile.acceptDevice({
            reqId: obj.mapping_id
        }).then(function(data){
             
                if(data.status==200 && data.data.statusOk==true){
                  // console.log("data is:"+JSON.stringify(data.data.data));  
                     var index=$scope.dataTab.indexOf(obj);
                    //console.log("index:"+index);
                    $scope.dataTab.splice(index, 1);
                }            
            }),function(data){
                console.log("Error:"+data);
            }
                    
                    
                }
                console.log("DataReturned:"+JSON.stringify(data.data));
                }else{
                    alert("Some network error!");
                    return;
                }            
            }),function(data){
                console.log("Error:"+data);
            }
        
        
       /* return;
        //check existing or not*/
        
        /*
        RequestMobile.acceptDevice({
            reqId: obj.mapping_id
        }).then(function(data){
             
                if(data.status==200 && data.data.statusOk==true){
                  // console.log("data is:"+JSON.stringify(data.data.data));  
                     var index=$scope.dataTab.indexOf(obj);
                    //console.log("index:"+index);
                    $scope.dataTab.splice(index, 1);
                }            
            }),function(data){
                console.log("Error:"+data);
            }*/
    }
    
    $scope.rejectMobReq=function(obj){
         console.log(obj);
        RequestMobile.rejectDevice({
            reqId: ""+obj.mapping_id
        }).then(function(data){
             
                if(data.status==200 && data.data.statusOk==true){
                  // console.log("data is:"+JSON.stringify(data.data.data));  
                     var index=$scope.dataTab.indexOf(obj);
                    //console.log("index:"+index);
                    $scope.dataTab.splice(index, 1);
                }            
            }),function(data){
                console.log("Error:"+data);
            }
        
    }
    
    
    
    
    
});

