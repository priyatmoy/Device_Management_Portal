angular.module('MyApp')
  .controller('UserHistoryCtrl', function($scope, $rootScope, $location, $window,$http,ngDialog,$firebase) {
     $rootScope.view_class = "wrapper";
    $rootScope.body_class = "cream-background";
    $rootScope.show_wrapper = false;
    $rootScope.containerId="wrapper";
   initializeSidebarTopbarScript();
    var arealistArray=[];
    $('#dataTable-container').show();
    $('.loader').hide();
	//select * from user_registration where  status='accept';
	 const rootRef = firebase.database().ref().child('user_registration').orderByKey();
	 rootRef.once('value', function(snap) {
       //console.log('accounts matching user', snap.val())
	    snap.forEach(function(childSnapshot) {
      // key will be "ada" the first time and "alan" the second time
      var key = childSnapshot.key;
      // childData will be the actual contents of the child
      var childData = childSnapshot.val();

			   if(childData.status == "accept"){
					arealistArray.push(childData);
	     }

	
	
	  // if(childData.EmpNo == EmpNo && childData.password == Pass){
		// console.log(key);
	    // console.log(childData);
			  // data = childData;
	  // }

		})
		// $scope.arealist = arealistArray;
			 						// console.log($scope.arealist);
		$scope.dataTable = arealistArray;
		$scope.$apply();		
			console.log( $scope.dataTable);
                      $('.dataTable-container').show();
                     $('.loader').hide();
    
     })
	 
     // userHistory.getUserInfo().then(function(data){
             
                // if(data.status==200){

                   // console.log("data is:"+JSON.stringify(data.data.data));  
                    // //$scope.dataTable=[];
                    // $scope.dataTable=data.data.data; 
                    
                    
                    // console.log($scope.dataTable);
                     // $('#dataTable-container').show();
                    // $('.loader').hide();
                // }            
            // }),function(data){
                // console.log("Error:"+data);
            // }

             $scope.selectedUser=function(user){

                 // userHistory.getUserHistory({
           // empno:""+user.empid
       // }).then(function(data){
             
                // if(data.status==200){
                   // console.log("data is:"+JSON.stringify(data.data.data));  
                    // //$scope.dataTable=[];
                    // $scope.dataTab=data.data.data; 
                    
                    // console.log($scope.dataTab);
                     // $('#dataTable-container').show();
                    // $('.loader').hide();
                // }            
            // }),function(data){
                // console.log("Error:"+data);
            // }
       
       console.log(user);
    }
    



    
    

    
    
    
    
    
    
    
    
    
});
