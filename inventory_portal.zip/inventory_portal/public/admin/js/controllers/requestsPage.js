
angular.module('MyApp')
  .controller('RequestsPageCtrl', function($scope, $rootScope, $location, $window,$http,ngDialog,$firebase, $firebaseArray,$firebaseObject) {
     $rootScope.view_class = "wrapper";
    $rootScope.body_class = "cream-background";
    $rootScope.show_wrapper = false;
    $rootScope.containerId="wrapper";
   initializeSidebarTopbarScript();

    console.log($rootScope.currentUser);
    $scope.userDet=JSON.stringify($rootScope.currentUser);
    $scope.initialize=function(){
		var arealistArray=[];
		$scope.arealist=[]; 
        $('.dataTable-container').hide();
         $('.loader').show();

	 var EmpNo = $rootScope.currentUser.username;
	 var Pass = $rootScope.currentUser.password;
	 const rootRef = firebase.database().ref().child('user_registration').orderByKey();
	 rootRef.once('value', function(snap) {
       //console.log('accounts matching user', snap.val())
	    snap.forEach(function(childSnapshot) {
      // key will be "ada" the first time and "alan" the second time
      var key = childSnapshot.key;
      // childData will be the actual contents of the child
      var childData = childSnapshot.val();

			   if(childData.status == "pending"){
					arealistArray.push(childData);
	     }

	
	
	  // if(childData.EmpNo == EmpNo && childData.password == Pass){
		// console.log(key);
	    // console.log(childData);
			  // data = childData;
	  // }

		})
		// $scope.arealist = arealistArray;
			 						// console.log($scope.arealist);
		$scope.dataTable = arealistArray;
		$scope.$apply();		
			console.log( $scope.dataTable);
                      $('.dataTable-container').show();
                     $('.loader').hide();
    
     })



	//.then(function($scope.arealist){
             
                 // // if(data.status==200){
                    // // console.log("data is:"+JSON.stringify(data.data.data));  
                    // // //$scope.dataTable=[];
                    // // $scope.dataTable=data.data.data; 
                    
                     // console.log($scope.dataTable);
                      // $('#dataTable-container').show();
                     // $('.loader').hide();
                 // }            
             // }),function(data){
                // console.log("Error:"+data);
             // }
	}



        $scope.reason=function(obj){
       //alert("device id: "+deviceId); 
          //$scope.selectedDeviceid=deviceId;   
        /*ngDialog.open({ template: 'mobileDetailsTemplate' });*/
        $scope.rejectObj=obj;
        ngDialog.open({
        template: 'userDetailsTemplate.html',
            showClose: false,
            className: 'ngdialog ngdialog-theme-default',
            scope : $scope // This line did the trick
        });
        
       /* ngDialog.open({
            template: '<p>Devide id is '+$scope.selectedDeviceid+'</p>',
            controller: function($scope) {
        // controller logic
        }
        });*/
        
    }
        $scope.accept=function(obj){
            $scope.acceptObj=obj;
            ngDialog.open({
			template: 'userDetailsTemplateAccept.html',
            showClose: false,
            className: 'ngdialog ngdialog-theme-default',
            scope : $scope // This line did the trick
        });
        }
        
        $scope.confirm=function(obj){
			//EmpNo =  obj.emp_no;
            console.log("confirmed:"+JSON.stringify(obj));
            //"update user_registration set status='accept' where (emp_no=$1 AND status='pending'
			//var rootRef = firebase.database().ref('user_registration').child();//'user-posts/' + myUserId
			//var key = rootRef.push(obj.EmpNo);
			 // const rootRef = firebase.database().ref('user_registration');

			 
			
			const rootRef = firebase.database().ref().child('user_registration');
			$scope.deviceData = $firebaseObject(rootRef);
			
			$scope.deviceData.$loaded()
				.then(function(data) {
				console.log(data === $scope.deviceData); // true
				//$scope.devicesArray= data;
				 angular.forEach(data, function(value, key) {
					console.log(value);
					console.log(key);
				if(obj.EmpNo == value.EmpNo){
					//var key = rootRef.push().key;
				 var update = {};
				 update[key] = {
					EmpNo:obj.EmpNo,
					EmpName: obj.EmpName ,
					EmpUserName:obj.EmpUserName ,
					Empmanager:obj.Empmanager,
					EmpProject:obj.EmpProject,
					EmpPhone:obj.EmpPhone,
					EmpAccount:obj.EmpAccount,
					EmpRole:obj.EmpRole,
					EmpUnit:obj.EmpUnit,
					EmpPassword:'Welcome@1',
					status : 'accept'
				 }
				   rootRef.update(update);
				   alert("User Accepted Successfully!!");
						var index=$scope.dataTable.indexOf(obj);
						// //console.log("index:"+index);
						 $scope.dataTable.splice(index, 1);
						 ngDialog.close();
				}
				
	
			// var update = {};
			// update['user_registration' + key] = {
				// status : 'accept'
			// }
			  // rootRef.update(update);
             // // RequestUserService.acceptUserAdmin({
                 // EmpNo: obj.emp_no
             // }).then(function(data){
             
                // if(data.status==200 && data.data.statusOk==true){
                    // //alert("User Accepted Successfully!!");
                   // var index=$scope.dataTable.indexOf(obj);
                    // //console.log("index:"+index);
                    // $scope.dataTable.splice(index, 1);
                    // ngDialog.close();
                // } else{
                    // alert("Error.. Status not changed.");
                // }          
            // }),function(data){
                // console.log("Error:"+data);
            // }
            
            
            
        })
		});
		}
        
        $scope.rejectUserButton=function(obj){
            const rootRef = firebase.database().ref().child('user_registration');
			$scope.deviceData = $firebaseObject(rootRef);
			
			$scope.deviceData.$loaded()
				.then(function(data) {
				console.log(data === $scope.deviceData); // true
				//$scope.devicesArray= data;
				 angular.forEach(data, function(value, key) {
					console.log(value);
					console.log(key);
				if(obj.EmpNo == value.EmpNo){
					//var key = rootRef.push().key;
				 var update = {};
				 update[key] = {
					EmpNo:obj.EmpNo,
					EmpName: obj.EmpName ,
					EmpUserName:obj.EmpUserName ,
					Empmanager:obj.Empmanager,
					EmpProject:obj.EmpProject,
					EmpPhone:obj.EmpPhone,
					EmpAccount:obj.EmpAccount,
					EmpRole:obj.EmpRole,
					EmpUnit:obj.EmpUnit,
					EmpPassword:'Welcome@1',
					status : 'Reject',
					reason : $scope.rejectObj.reason
				 }
				   rootRef.update(update);
				   alert("User rejected Successfully!!");
						var index=$scope.dataTable.indexOf($scope.rejectObj);
						// //console.log("index:"+index);
						 $scope.dataTable.splice(index, 1);
						 ngDialog.close();
				}
				 });
				});
		
            // RequestUserService.rejectUserAdmin({
                 // empno: ""+$scope.rejectObj.emp_no,
                // reason:""+getreason
             // }).then(function(data){
             
                // if(data.status==200 && data.data.statusOk==true){
                    // alert("User Rejected Successfully!!");
                   // var index=$scope.dataTable.indexOf($scope.rejectObj);
                    // //console.log("index:"+index);
                    // $scope.dataTable.splice(index, 1);
                    // ngDialog.close();
                // } else{
                    // alert("Error.. Status not changed.");
                // }          
            // }),function(data){
                // console.log("Error:"+data);
            // }
            
            
        }
    
    
    
});