angular.module('MyApp')
  .controller('SideBarCtrl', function($scope, $rootScope, $location, $window) {
   
    
    function printMe(str){
        console.log(str);
    }
    function strinfifyMe(str){
        console.log(""+JSON.stringify(str));
    }
    
     initializeSidebarTopbarScript();
    printMe("Loaded Sidebar");
}).controller('HeaderCtrl', function($scope, $rootScope, $location, $window) {
   
     //$scope.isCollapsed = true;
    function printMe(str){
        console.log(str);
    }
    function strinfifyMe(str){
        console.log(""+JSON.stringify(str));
    }
    
    $scope.getNameOfUser=function(){
        //console.log("Name is:"+$rootScope.currentUser.name.split(" "));
        return ""+$rootScope.currentUser.name.split(" ")[0];
    }
    
    $scope.logoutBtnClick=function(){
        delete $window.localStorage.user;
       // $location.path('/');
	   $window.location.href = '/';
    }
     //initializeSidebarTopbarScript();
    printMe("Loaded Header");
});