angular.module('MyApp')
  .controller('addUserCtrl', function($scope, $rootScope, $location, $window,firebase, $firebaseArray) {
     $rootScope.view_class = "wrapper";
    $rootScope.body_class = "cream-background";
    $rootScope.show_wrapper = false;
    $rootScope.containerId="wrapper";
    


    $scope.register_admin=function(user){
       // alert("user registered");
        //console.log(JSON.stringify(user));
		const ref = firebase.database().ref().child('user_registration');
		$scope.registerUser = $firebaseArray(ref);

        $scope.registerUser.$add({
		EmpNo:user.empid,
        EmpName: user.name ,
        EmpUserName:user.email ,
        Empmanager:user.manager_id,
        EmpProject:user.project,
        EmpPhone:user.phno,
        EmpAccount:user.account,
        EmpRole:user.role,
        EmpUnit:user.unit,
        EmpPassword:'Welcome@1',
        status:'accept',     
        }).then(function(data){
              alert("Your request has been sent successfully. You will be able to login once your request is approved. Contact Admin for more details.");
            $location.path('/');

              // $scope.user = angular.copy($scope.master);
        //         if(data.data.statusOk==true){
        //            user.role=data.data.data.emp_role;
        //            user.name=data.data.data.emp_name;
        //            $window.localStorage.user = JSON.stringify(user);
        //             $('.text-red').empty();
        //            $('.text-red').append("Redirecting..");
                    
        //             if(user.role=='admin'){
        //                  $location.path('/admin');
        //             }else{
        //                 $location.path('/user');
        //             }
                    
                    
        //         }else{
        // $('.text-red').empty();
        // $('.text-red').append("Username/Password Incorrect");
        // }            
            }),function(data){
                console.log("Error:"+data);
            }
		//.then(function(data){
           // // console.log(JSON.stringify(data.data));
            // // if(ref.key){
                // alert("User Added Successfully!");
				// $location.path('/');
            // // }else{
                // // alert("Error.Check Employee id..User Not Added!");
            // // }
             // /* alert("Your request has been sent successfully");
               // $scope.user = angular.copy($scope.master);*/
            // }),function(data){
            // alert("Error... Contact Administrator.");
               // // console.log("Error:"+data);
            // }
        

    }
    
});