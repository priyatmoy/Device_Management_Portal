angular.module('MyApp')
  .controller('DeviceHistoryCtrl', function($scope, $rootScope, $location, $window,$http,ngDialog,$firebase, $firebaseObject) {
     $rootScope.view_class = "wrapper";
    $rootScope.body_class = "cream-background";
    $rootScope.show_wrapper = false;
    $rootScope.containerId="wrapper";
   initializeSidebarTopbarScript();
$('#dataTable-container').show();
                    $('.loader').hide();
    


 $scope.devicesArray=[];
       // EditDeviceService.getAllDeviceDetails().then(function(data){
             
               // if(data.status==200){
                   // console.log("data is:"+JSON.stringify(data.data)); 
                    // $scope.devicesArray=data.data.data;
                   // // if($scope.devicesArray.length>0)
                      // // $scope.dev.device_id="-Select-";//+data.data.data[0].imei_number;
                   
                    // //$scope.dataTable=[];
                // }             
            // }),function(data){
                // console.log("Error:"+data);
            // }
	const rootRef = firebase.database().ref().child('devices');
	$scope.deviceData = $firebaseObject(rootRef);
	
	$scope.deviceData.$loaded()
		.then(function(data) {
			console.log(data === $scope.deviceData); // true
			 angular.forEach(data, function(value, key) {

		  var exists = false;
		angular.forEach($scope.devicesArray, function(val2, key) {
			if(angular.equals(value.imeiNumber, val2.imeiNumber)){ exists = true }; 
		});
		if(exists == false && value.imeiNumber != "") { $scope.devicesArray.push(value); }
	
       });
	   
			if($scope.devicesArray.length>0)
				$scope.deviceId="-Select-";//+data.data.data[0].imei_number;
				console.log($scope.devicesArray);
                   
		})
		.catch(function(error) {
           console.error("Error:", error);
		});


function getdeviceDetailsFromDeviceId(deviceId){
        for(var i=0;i<$scope.devicesArray.length;i++)
            if($scope.devicesArray[i].device_id==deviceId.device_id)
            {
           // alert("ok");
                return i;
            }
        return -1;
    }
    $scope.selectedChanges=function(device){
       
        $scope.device=$scope.devicesArray[getdeviceDetailsFromDeviceId(device)];
       // console.log(JSON.stringify($scope.device.device_id));
        //var test= JSON.stringify($scope.device.device_id);
       // var test=$scope.device.device_id;
       console.log(device);
    
    // deviceHistory.getDeviceHistory({device_id:device.device_id}).then(function(data){
             
                // if(data.status==200){
                   // console.log("data is:"+JSON.stringify(data));  
                    // $scope.dataTab=data.data.data; 
                    // console.log($scope.dataTab);
                     
                // }            
            // }),function(data){
                // console.log("Error:"+data);
            // }
    

}



    
    console.log($rootScope.currentUser);
    $scope.userDet=JSON.stringify($rootScope.currentUser);
    
    
        
     
    
    
    

    
    
    
    
    
    
    
    
    
});
