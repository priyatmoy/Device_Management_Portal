var pgp=require('pg-promise')({});
var cn={
    host: 'localhost',
    port: 5432,
    database: 'device_tracking',
    user: 'postgres',
    password: 'admin'
}
var db=pgp(cn);

module.exports = {
  getLoginDetails: getLoginDetails,
  registerUser:registerUser,
  getPendingUserDetails: getPendingUserDetails,
  insertDeviceByAdmin: insertDeviceByAdmin,
  getAllDevicesDetailsAdmin:getAllDevicesDetailsAdmin,
    updateAccountPassword:updateAccountPassword,
    acceptUserAdmin:acceptUserAdmin,
    getAvailableDevicesFromDateRange:getAvailableDevicesFromDateRange,
    rejectUserByAdmin:rejectUserByAdmin,
    getDeviceRequest:getDeviceRequest,
    getDeviceDetails:getDeviceDetails,
    getAllVisibleDevices:getAllVisibleDevices,
    adminDashboardMetaData:adminDashboardMetaData,
    getUserReqHistory:getUserReqHistory,
    acceptMobileRequest:acceptMobileRequest,
    rejectMobileRequest:rejectMobileRequest,
    insertDeviceRequest:insertDeviceRequest,
    updateDeviceAdmin:updateDeviceAdmin,
    returnDevice:returnDevice,
    getMappingAdmin:getMappingAdmin,
    completeRequestAdmin:completeRequestAdmin,
    checkBeforeApprove:checkBeforeApprove,
    getDeviceHistory:getDeviceHistory,
    getAllUsers:getAllUsers
    
};

function getLoginDetails(req,res,next){
     var empNo = ""+req.body.empno;
    var pass = req.body.pass;
    
    /*var empNo="123";
    var pass="abcde";*/
    //console.log(empNo +" pass="+pass);
   db.one("select emp_no,emp_name,emp_role from user_registration where (emp_no=$1 AND emp_password=$2 AND status='accept'); ",[empNo,pass])
        .then(function (data) {
            data.status(200)
          .json({
                 statusOk: true,
                data: data,
                message: 'Retrieved ALL Tasks'
                });       
                            })
            .catch(function (err) {
       console.log(err);
               res.json({
                 statusOk: false,
                message: 'Error in Query'
                });
                    });
}

function registerUser(req,res,next){
    var empNo = ""+req.body.empid;
    var empName = ""+req.body.empname;
    var empUsername = ""+req.body.empusername;
    var empManager = ""+req.body.empmanager;
    var empPhone = ""+req.body.empphone;
    var empProject = ""+req.body.empproject;
    var empAccount = ""+req.body.empaccount;
    var empUnit = ""+req.body.empunit;
    var empRole = ""+req.body.emprole;
    var empPass = ""+req.body.emppassword;
    var status = ""+req.body.status;

    
    /*var empNo="123";
    var pass="abcde";*/   
    //console.log(empNo +" pass="+pass);
 db.none('INSERT INTO user_registration(emp_no, emp_name, emp_username, emp_manager, emp_phone, emp_project,emp_account, emp_unit, emp_role, emp_password, status) values($1, $2, $3, $4,$5,$6,$7,$8,$9,$10,$11)',
    [empNo, empName, empUsername, empManager, empPhone, empProject,empAccount, empUnit, empRole, empPass, status]).then(function (data) {res.status(200).json({
                 statusOk: true,
                //data: data,
                message: 'Data Inserted successfully'
                });       
                            })
            .catch(function (err) {
       console.log(err);
               res.json({
                 statusOk: false,
                message: 'Error in Query'
                });
                    });

}




// function getPendingUserDetails(req,res,next){
     
    // /*var empNo="123";
    // var pass="abcde";*/
    // //console.log(empNo +" pass="+pass);
   // db.any("select * from user_registration where  status='pending'; ")
        // .then(function (data) {
            // res.status(200)
          // .json({
                 // statusOk: true,
                // data: data,
                // message: 'Retrieved ALL Pending Users'
                // });       
                            // })
            // .catch(function (err) {
       // console.log(err);
               // res.json({
                 // statusOk: false,
                // message: 'Error in Query'
                // });
                    // });
// }

// function insertDeviceByAdmin(req,res,next){
    
// var sim = ""+req.body.sim;
    // var visibility = ""+req.body.visibility;
    // var id = ""+req.body.id;
    // var deviceModel = ""+req.body.deviceModel;
    // var softVersion = ""+req.body.softVersion;
    // var deviceStatus = ""+req.body.deviceStatus;
    // var imei = ""+req.body.imei;
    // var password = ""+req.body.password;
    // var phone = ""+req.body.phone;
    
    // /*var empNo="123";
    // var pass="abcde";*/   
    // //console.log(empNo +" pass="+pass);
 // db.one('INSERT INTO devices(device_id, device_model, software_version, imei_number, device_password, status,visibility, sim_card, phone_number) values($1, $2, $3, $4,$5,$6,$7,$8,$9) returning imei_number',
    // [id, deviceModel,softVersion,imei,password,deviceStatus,visibility,sim,phone]).then(function (data) {res.status(200).json({
                 // statusOk: true,
                // data: data,
                // message: 'Data Inserted successfully'
                // });       
                            // })
            // .catch(function (err) {
       // console.log(err);
               // res.json({
                 // statusOk: false,
                // message: 'Error in Query'
                // });
                    // });

// }



// function getAllDevicesDetailsAdmin(req,res,next){
    
 
   // db.any("select * from devices; ")
        // .then(function (data) {
            // res.status(200)
          // .json({
                 // statusOk: true,
                // data: data,
                // message: 'Retrieved ALL Devices'
                // });       
                            // })
            // .catch(function (err) {
       // console.log(err);
               // res.json({
                 // statusOk: false,
                // message: 'Error in Query'
                // });
                    // });
// }


function updateAccountPassword(req, res, next) {
    var pass=""+req.body.newPassword;
    var empno=""+req.body.empno;
  db.none("update user_registration set emp_password=$1 where (emp_no=$2 AND status='accept');",
    [pass,empno])
    .then(function () {
      res.status(200)
        .json({
          statusOk: true,
          message: 'password changed'
        });
    })
    .catch(function (err) {
       console.log(err);
               res.json({
                 statusOk: false,
                message: 'password not changed'
                });
    });
}

// function acceptUserAdmin(req,res,next){
     // var empno=""+req.body.empno;
  // db.none("update user_registration set status='accept' where (emp_no=$1 AND status='pending');",
    // [empno])
    // .then(function () {
      // res.status(200)
        // .json({
          // statusOk: true,
          // message: 'Status changed to Accept'
        // });
    // })
    // .catch(function (err) {
       // console.log(err);
               // res.json({
                 // statusOk: false,
                // message: 'Status not changed'
                // });
    // });
// }

// function getAvailableDevicesFromDateRange(req,res,next){
   // /* var datefrom=new Date(1499976000000);
    // var dateto=new Date(Number('1500066000000'));
    // console.log(datefrom);
    // console.log(dateto);*/
    // var fromDate=""+req.body.fromDate;
    // var toDate=""+req.body.toDate;
    
    // /*console.log(fromDate);
    // console.log(toDate);*/
    // //console.log(dateFrom.toISOString()+"");
   // var empno=""+req.body.empno;
    // //19 July, 17 2:00am : 
  // db.any("select device_id,imei_number,device_password,device_model,software_version,(select emp_username from user_registration where emp_no=$3 AND status='accept'),(select emp_manager from user_registration where emp_no=$3 AND status='accept'),(select emp_project from user_registration where emp_no=$3 AND status='accept') from devices where device_id NOT IN( select distinct device_id from mapping where (status='accept') AND (( from_date >=to_timestamp($1, 'dd-mm-yyyy hh24:mi') AND from_date <=to_timestamp($2, 'dd-mm-yyyy hh24:mi')) OR (to_date >=to_timestamp($1, 'dd-mm-yyyy hh24:mi') AND to_date <=to_timestamp($2, 'dd-mm-yyyy hh24:mi')) OR (from_date <= to_timestamp($1, 'dd-mm-yyyy hh24:mi') AND to_date>=to_timestamp($2, 'dd-mm-yyyy hh24:mi') )) ) AND devices.visibility='Visible';",[fromDate,toDate,empno])
    // .then(function (data) {
      // res.status(200)
        // .json({
          // data: data,
          // statusOk: true,
          // message: 'available devices'
        // });
    // })
    // .catch(function (err) {
       // console.log(err);
               // res.json({
                 // statusOk: false,
                // message: 'query Error'
                // });
    // });
    
    
// }



function rejectUserByAdmin(req,res,next){
    var empno=""+req.body.empno;
    var reason=""+""+req.body.reason;
    var notification='You are not authorized.';
    db.tx(t => {
        // this.ctx = transaction config + state context;
        return t.batch([
            t.none("delete from user_registration where (emp_no=$1 AND status='pending');", [empno]),
            t.none("INSERT INTO rejected_user(emp_no, reason,status,notification,date_timestamp) VALUES($1, $2,'rejected',$3,now());", [empno,reason,notification])
        ]);
    })
    .then(data => {
        // success;
        console.log(data);
        console.log('Success!');
         res.status(200)
        .json({
          statusOk: true,
          message: 'User Rejected Successfully!'
        });
    })
    .catch(error => {
        console.log('ERROR:', error);
         res.json({
                 statusOk: false,
                message: 'Error.. processing transactions'
                });
    });
}


// function getDeviceRequest(req,res,next){
     // db.any("select m.mapping_id,m.comment,m.device_id,m.emp_no,u.emp_username,to_char(m.from_date, 'DD Mon,YY HH:miam') as from_date,to_char(m.to_date, 'DD Mon,YY HH:miam') as to_date from mapping m inner join user_registration u on m.emp_no=u.emp_no where m.status='pending' order by m.mapping_id desc;")
        // .then(function (data) {
         // res.status(200).json({
             // data: data,
             // statusOk: true,
             // message: 'Device Requests'
        // });
    // })
    // .catch(function (err) {
       // console.log(err);
               // res.json({
                 // statusOk: false,
                // message: 'query Error'
                // });
    // });
// }


function getDeviceDetails(req,res,next){
    var device=""+req.body.device_id;
     db.any("select * from devices where device_id=$1;",[device])
        .then(function (data) {
         res.status(200).json({
             data: data,
             statusOk: true,
             message: 'All Devices'
        });
    })
    .catch(function (err) {
       console.log(err);
               res.json({
                 statusOk: false,
                message: 'query Error'
                });
    });
}


function getAllVisibleDevices(req,res,next){
     db.any("select * from devices where visibility='Visible';")
        .then(function (data) {
         res.status(200).json({
             data: data,
             statusOk: true,
             message: 'All Visible Devices'
        });
    })
    .catch(function (err) {
       console.log(err);
               res.json({
                 statusOk: false,
                message: 'query Error'
                });
    });
}


// function adminDashboardMetaData(req,res,next){
   
    // db.tx(t => {
        // // this.ctx = transaction config + state context;
        // return t.batch([
            // t.one("select count(*) as pending_user from user_registration where status='pending';"),
            // t.one("select count(*) as pending_dev_req from mapping where status='pending';"),
            // t.one("select count(*) as tot_dev from devices;"),
            // t.one("select distinct count(device_id) as avail_dev from mapping where status='accept' or status='WACK';")
            
        // ]);
    // })
    // .then(data => {
        // // success;
        // //console.log(data);
       // // console.log('Success!');
         // res.status(200)
        // .json({
          // statusOk: true,
          // data: data,
          // message: 'Meta Data Successfully!'
        // });
    // })
    // .catch(error => {
        // console.log('ERROR:', error);
         // res.json({
                 // statusOk: false,
                // message: 'Error.. getting metaData'
                // });
    // });
// }


function getUserReqHistory(req,res,next){
    var empno=""+req.body.empno;
     db.any(" select m.mapping_id as request_id,m.device_id as device_id,m.emp_username as username,to_char(m.from_date, 'DD Mon,YY HH:miam') as from_date,to_char(m.to_date, 'DD Mon,YY HH:miam') as to_date,m.status as status,m.comment as comment,d.device_model as dev_model from mapping m inner join devices d on m.device_id=d.device_id where m.emp_no=$1 order by from_date desc;",[empno])
        .then(function (data) {
         res.status(200).json({
             data: data,
             statusOk: true,
             message: 'User Request History'
        });
    })
    .catch(function (err) {
       console.log(err);
               res.json({
                 statusOk: false,
                message: 'query Error'
                });
    });
}


function acceptMobileRequest(req,res,next){
    var reqid=""+req.body.reqId;
    //console.log("Req:"+reqid);
     db.none(" update mapping set status='accept' where (mapping_id=$1 AND status='pending');",[Number(reqid)])
        .then(function (data) {
         res.status(200).json({
            // data: data,
             statusOk: true,
             message: 'Device Request Accepted'
        });
    })
    .catch(function (err) {
       console.log(err);
               res.json({
                 statusOk: false,
                message: 'query Error'
                });
    });
}

function rejectMobileRequest(req,res,next){
    var reqid=""+req.body.reqId;
    //console.log("Req:"+reqid);
     db.none(" update mapping set status='reject' where (mapping_id=$1 AND status='pending');",[Number(reqid)])
        .then(function (data) {
         res.status(200).json({
            // data: data,
             statusOk: true,
             message: 'Device Request Rejected'
        });
    })
    .catch(function (err) {
       console.log(err);
               res.json({
                 statusOk: false,
                message: 'query Error'
                });
    });
}



function insertDeviceRequest(req,res,next){
    
    var device_id = ""+req.body.device_id;//
    var empno = ""+req.body.empno;//
    var emp_username = ""+req.body.emp_username;//
    var to_date = ""+req.body.to_date;//
    var from_date = ""+req.body.from_date;//
    var status = "pending";
    var comment = ""+req.body.comment;
    
    /*var empNo="123";
    var pass="abcde";*/   
    //console.log(empNo +" pass="+pass);
 db.none("INSERT INTO mapping(device_id, emp_no,emp_username, from_date, to_date,status, comment) values($1, $2, $3, to_timestamp($4, 'dd-mm-yyyy hh24:mi'),to_timestamp($5, 'dd-mm-yyyy hh24:mi'),$6,$7);" ,
    [device_id, empno,emp_username,from_date,to_date,status,comment]).then(function (data) {res.status(200).json({
                 statusOk: true,
                data: data,
                message: 'Data Inserted successfully'
                });       
                            })
            .catch(function (err) {
       console.log(err);
               res.json({
                 statusOk: false,
                message: 'Error in Query'
                });
                    });

}


// function updateDeviceAdmin(req,res,next){
    // console.log("sim:"+req.body.sim_card);
    // var sim = ""+req.body.sim_card;
    // var visibility = ""+req.body.visibility;
    // var id = ""+req.body.device_id;
    // var deviceModel = ""+req.body.device_model;
    // var softVersion = ""+req.body.software_version;
    // var deviceStatus = ""+req.body.status;
    // var imei = ""+req.body.imei_number;
    // var password = ""+req.body.device_password;
    // var phone = ""+req.body.phone_number;
    // console.log("myDate:"+sim);
    // db.none("UPDATE devices set device_model=$1,software_version=$2,imei_number=$3,device_password=$4,status=$5,visibility=$6,sim_card=$7,phone_number=$8 where device_id=$9;" ,
    // [deviceModel,softVersion,imei,password,deviceStatus,visibility,sim,phone,id]).then(function (data) {res.status(200).json({
                 // statusOk: true,
                // message: 'Device updated successfully'
                // });       
                            // })
            // .catch(function (err) {
       // console.log(err);
               // res.json({
                 // statusOk: false,
                // message: 'Error in Query'
                // });
                    // });
    
// }



function returnDevice(req,res,next){
    
    var reqid = ""+req.body.request_id;
    var status = "WACK";
    
    //console.log("myDate:"+sim);
    db.none("UPDATE mapping set status=$1 where mapping_id=$2 and status='accept';" ,
    [status,reqid]).then(function (data) {res.status(200).json({
                 statusOk: true,
                message: 'Device Returned from user side successfully'
                });       
                            })
            .catch(function (err) {
       console.log(err);
               res.json({
                 statusOk: false,
                message: 'Error in Query'
                });
                    });
    
}


function getMappingAdmin(req,res,next){
    db.any("select mapping_id,device_id,emp_no,emp_username,to_char(from_date, 'DD Mon,YY HH:miam') as from_date,to_char(to_date, 'DD Mon,YY HH:miam') as to_date,status from mapping where status='accept' or status='WACK'; ")
        .then(function (data) {
            res.status(200)
          .json({
                 statusOk: true,
                data: data,
                message: 'Retrieved ALL mappings'
                });       
                            })
            .catch(function (err) {
       console.log(err);
               res.json({
                 statusOk: false,
                message: 'Error in Query'
                });
                    });
}

function completeRequestAdmin(req,res,next){
    
    var reqid = ""+req.body.request_id;
    var status = "complete";
    
    //console.log("myDate:"+sim);
    db.none("UPDATE mapping set status=$1 where mapping_id=$2 and (status='accept' or status='WACK');" ,
    [status,reqid]).then(function (data) {res.status(200).json({
                 statusOk: true,
                message: 'Device Request Completed successfully'
                });       
                            })
            .catch(function (err) {
       console.log(err);
               res.json({
                 statusOk: false,
                message: 'Error in Query'
                });
                    });
    
}


function checkBeforeApprove(req,res,next){
    
     var device_id = ""+req.body.device_id;
    var to_date = ""+req.body.to_date;
    var from_date = ""+req.body.from_date;


    
    /*var empNo="123";
    var pass="abcde";*/   
    //console.log(empNo +" pass="+pass);
 db.one(" select count(*) as device_count from mapping where (status='accept' AND device_id=$1) AND (( from_date >=to_timestamp($2, 'dd-mm-yyyy hh24:mi') AND from_date <=to_timestamp($3, 'dd-mm-yyyy hh24:mi')) OR (to_date >=to_timestamp($2, 'dd-mm-yyyy hh24:mi') AND to_date <=to_timestamp($3, 'dd-mm-yyyy hh24:mi')) OR (from_date <= to_timestamp($2, 'dd-mm-yyyy hh24:mi') AND to_date>=to_timestamp($3, 'dd-mm-yyyy hh24:mi') ));" ,
    [device_id,from_date,to_date]).then(function (data) {
    // console.log("device in use:"+data.device_count);
     var isAvailable=true;
     if(Number(data.device_count)>0)
         var isAvailable=false;
     
     res.status(200).json({
                 statusOk: true,
              //  data: data,
            canApprove:isAvailable,
                message: 'Data Inserted successfully'
                });       
                            })
            .catch(function (err) {
       console.log(err);
               res.json({
                 statusOk: false,
                message: 'Error in Query'
                });
                    });

    
    
}


// function getDeviceHistory(req,res,next){
    // var deviceid=""+req.body.device_id;
    // //console.log(imei);
     // db.any("select m.mapping_id as request_id,m.device_id as device_id,m.imei_number as imei,m.emp_no as employee,m.emp_username as username,to_char(m.from_date, 'DD Mon,YY HH:miam') as from_date,to_char(m.to_date, 'DD Mon,YY HH:miam') as to_date,m.status as status,m.comment as comment,d.device_model as dev_model from mapping m  inner join devices d on m.device_id=d.device_id where m.device_id=$1;",[deviceid])
        // .then(function (data) {
         // res.status(200).json({
             // data: data,
             // statusOk: true,
             // message: 'Device History'
        // });
    // })
    // .catch(function (err) {
       // console.log(err);
               // res.json({
                 // statusOk: false,
                // message: 'query Error'
                // });
    // });
// }

// function getAllUsers(req,res,next){

// db.any("select * from user_registration where  status='accept'; ")
        // .then(function (data) {
            // res.status(200)
          // .json({
                 // statusOk: true,
                // data: data,
                // message: 'Retrieved ALL Pending Users'
                // });       
                            // })
            // .catch(function (err) {
       // console.log(err);
               // res.json({
                 // statusOk: false,
                // message: 'Error in Query'
                // });
                    // });

// }