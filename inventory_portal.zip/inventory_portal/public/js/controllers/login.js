	angular.module('MyApp')
	  .controller('LoginCtrl', function($scope, $rootScope, $location, $window,$firebase) {
		$rootScope.view_class = "empty-class";
		$rootScope.body_class = "body-class";
	   // $rootScope.user_level = null;
		$rootScope.show_wrapper = false;
		
		function printMe(str){
			console.log(str);
		}
		function strinfifyMe(str){
			console.log(""+JSON.stringify(str));
		}
		

		$scope.login=function(user){
			$('.text-red').empty();
			//$('.text-red').append("Checking..");
			if(user== null || user.username == null || user.password==null || user.username.trim=="" || user.password.trim=="" ){
				$('.text-red').empty();
				$('.text-red').append("EmployeeNo/Password cannot be empty!");
				   return;
			}
			//console.log("data is:"+JSON.stringify(data));
			$rootScope.currentUser = user;
			var data;
			var EmpNo = user.username;
			var Pass = user.password;
			const rootRef = firebase.database().ref().child('user_registration').orderByKey();
			rootRef.once('value', function(snap) {
				snap.forEach(function(childSnapshot) {
			  // key will be "one" the first time and "two" the second time
			  var key = childSnapshot.key;
			  // childData will be the actual contents of the child
			  var childData = childSnapshot.val();
			  if(childData.EmpNo == EmpNo && childData.password == Pass){
					console.log(key);
					console.log(childData);
					data = childData;
			}

			});
			if(data){
				user.role=data.Role;
				user.name=data.EmpName;
				$window.localStorage.user = JSON.stringify(user);
		  
						// $('.text-red').empty();
						 //$('.text-red').append("Redirecting..");
							
						  if(user.role=='admin'){
							  $rootScope.$apply(function() {
								$location.path('/admin');
								console.log($location.path());
							  });
							   //$location.path('/admin');
						  }else if(user.role=='user'){
							  	$rootScope.$apply(function() {
								$location.path('/user');
								console.log($location.path());
							  });
							  //$location.path('/user');
						  }

			}else{
			 // $('.text-red').empty();
			  $('.text-red').append("EmployeeNo/Password Incorrect. Kindly contact Admin");
			}            
				 
		
			//perform validations
		   //make service call to authenticate and perform action accordingly
			
			
			
			 //validations
			
			 //LoginService.checkLogin({
			 //empno:user.username,
			 //pass: user.password    
			 //}).then(function(data){
				// // console.log("data is:"+JSON.stringify(data));
					 // if(data.data.statusOk){
						// user.role=data.data.data.emp_role;
						// user.name=data.data.data.emp_name;
						// $window.localStorage.user = JSON.stringify(user);
					   // // // console.log("UserInput:"+JSON.stringify(user));
						 // $('.text-red').empty();
						// $('.text-red').append("Redirecting..");
						
						 // if(user.role=='admin'){
							  // $location.path('/admin');
						 // }else if(user.role=='user'){
							 // $location.path('/user');
						 // }
						
						
					 // }else{
			 // $('.text-red').empty();
			 // $('.text-red').append("EmployeeNo/Password Incorrect. Kindly contact Admin");
			 // }            
				 // }),function(data){
					 // console.log("Error:"+data);
				 // }
			
			
			// if(user.username=='admin@admin' && user.password=='12345'){ //admin
				 // user.role='admin';
				// user.name="Sameer Gupta";
				// $window.localStorage.user = JSON.stringify(user);
				 // $('.text-red').empty();
				// $('.text-red').append("Redirecting..");
				// $location.path('/admin');
			// }else if(user.username=='user@admin' && user.password=='12345'){
				  // user.role='user';
				// $window.localStorage.user = JSON.stringify(user);
				 // $('.text-red').empty();
				// $('.text-red').append("Redirecting..");
				// $location.path('/user');
				
			// }else{
			// $('.text-red').empty();
			// $('.text-red').append("Username/Password Incorrect");
			// }
			  
		});
		}
		 
		
		
		$scope.registerBtnClick=function(){
			$location.path('/register');
		}
	});