angular.module('MyApp')
  .controller('HeaderCtrl', function($scope, $rootScope, $location, $window) {
   
     //$scope.isCollapsed = true;
    function printMe(str){
        console.log(str);
    }
    function strinfifyMe(str){
        console.log(""+JSON.stringify(str));
    }
   
    printMe("Loaded Header");
});