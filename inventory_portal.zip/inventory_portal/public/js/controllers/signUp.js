angular.module('MyApp')
  .controller('SignUpCtrl', function($scope, $rootScope, $location, $window, firebase, $firebaseArray) {
     $rootScope.view_class = "empty-class";
    $rootScope.body_class = "body-class";
    $rootScope.show_wrapper = false;
   /* if($rootScope.role==null)
        $location.path('/');*/
    
    $scope.cancelBtn=function(){
        $location.path('/');
    }
   // $scope.master={};
   function validationcheck(userObj){
        //console.log("in ValidateFunction"+JSON.stringify(userObj));
       if(userObj==null){
           alert("Please enter Values !");
           return false;
       }
       if(userObj.name == null || userObj.name.trim==""){
           alert("Please enter Full Name !");
           return false;
       }
       if(userObj.empid == null || userObj.empid.trim == ""){
           alert("Please enter Employee ID !");
           return false;
       }
       if(userObj.uname == null || userObj.uname.trim == ""){
           alert("Please enter Your Email !");
           return false;
       }
       if(userObj.phone == null || userObj.phone.trim == ""){
           alert("Please enter Your Phone/Mobile !");
           return false;
       }
       if(userObj.manager == null || userObj.manager.trim == ""){
           alert("Please enter Manager email !");
           return false;
       }
       if(userObj.account == null || userObj.account.trim == ""){
           alert("Please select Account !");
           return false;
       }
       if(userObj.project == null || userObj.project.trim == ""){
           alert("Please enter Project Code !");
           return false;
       }
       
       
       return true;
       
    }
    $scope.register=function(user){
        user.role="user";
        user.pass="Welcome@1";
        user.status="pending";
        console.log(user);
        
        

        if(!validationcheck(user)){
            //console.log("Validaion Working");
            return;
        }
                   // console.log("Valid Data");
		const ref = firebase.database().ref().child('user_registration');
		$scope.register = $firebaseArray(ref);
		 
		var newKey = ref.push().key;
            
        $scope.register.$add({
        EmpNo:user.empid,
        EmpName: user.name,
        EmpUserName:user.uname,
        Empmanager:user.manager,
        EmpProject:user.project,
        EmpPhone:user.phone,
        EmpAccount:user.account,
        EmpRole:user.role,
        EmpUnit:user.unit,
        EmpPassword:user.pass,
        status:user.status,    
        }).then(function(data){
              alert("Your request has been sent successfully. You will be able to login once your request is approved. Contact Admin for more details.");
            $location.path('/');

              // $scope.user = angular.copy($scope.master);
        //         if(data.data.statusOk==true){
        //            user.role=data.data.data.emp_role;
        //            user.name=data.data.data.emp_name;
        //            $window.localStorage.user = JSON.stringify(user);
        //             $('.text-red').empty();
        //            $('.text-red').append("Redirecting..");
                    
        //             if(user.role=='admin'){
        //                  $location.path('/admin');
        //             }else{
        //                 $location.path('/user');
        //             }
                    
                    
        //         }else{
        // $('.text-red').empty();
        // $('.text-red').append("Username/Password Incorrect");
        // }            
            }),function(data){
                console.log("Error:"+data);
            }
			
			ref.child(newKey).set($scope.register);
        



      /*  $scope.user1=[];
        
        $scope.user1.push(user);
        
        console.log($scope.user1);*/
        
    }
    
});