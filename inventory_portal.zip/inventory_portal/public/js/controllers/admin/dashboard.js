angular.module('MyApp')
  .controller('DashboardCtrl', function($scope, $rootScope, $location, $window) {
     $rootScope.view_class = "empty-class";
    $rootScope.body_class = "empty-class";
    $rootScope.show_wrapper = false;
    console.log($rootScope.currentUser);
    $scope.userDet=JSON.stringify($rootScope.currentUser);
   /* if($rootScope.role==null)
        $location.path('/');*/
    $scope.logout=function(){
        delete $window.localStorage.user;
        $location.path('/');
        
    }
    
});