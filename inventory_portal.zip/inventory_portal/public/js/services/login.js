// angular.module('MyApp')
  // .factory('LoginService', function($http) {
    // return {
       
    
       // checkLogin: function(data) {
		   // console.log("Hi");
        // //return $http.post('/api/loginAPI',data);
      // }
    // };
  // });