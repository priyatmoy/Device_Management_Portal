// angular.module('MyApp')
  // .factory('SignUpService', function($http) {
    // return {
       
    
       // register: function(data) {
        // return $http.post('/api/registerAPI',data);
      // }
    // };
  // });